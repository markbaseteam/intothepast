# ProjectAudio

---

## About

A reimagination of Catholic Girls by The Dangerous Summer

**Members:** Dustin Smith

---
## Catholic GPTs

![[tdscover.jpg]]

**Tracklist**

1. Catholic GPT
2. Catholic GPT2
3. Catholic GPT3

---

