# Anotherlife

---

## About

Members: Dustin Smith

---

## A Bitter Ending

![[abe.jpg]]

**Tracklist**

1. A Bitter Ending
2. August 19th, 2017
3. The Day You Came Back
4. Broken Vows
5. Devil
6. Heartstrings
7. I Just Need A Way Out
8. If Only Letting Go Was as Easy as Telling Someone to Let It Go
9. I'll See You
10. Letter
11. Prelude
12. Roses Are Red Violets Are Blue, Fuck Yo Whore
13. Runaway Bride
14. The Divorce Party
15. Thoughts of You

---

## A Bitter Winter

![[abw.jpg]]

**Tracklist**

1. A Bitter Winter
2. A Bitter Winter II
3. A Bitter Winter Remix
4. A Molly Jolly Christmas
5. December
6. December New
7. Soul Collector
8. Winter in Hell

---
## Links

- [Anotherlife - Home](https://www.facebook.com/anotherlifemusic)
- [Anotherlife - YouTube - YouTube](https://www.youtube.com/channel/UCtJKjr_KvNpoNU6QIZA922A?view_as=subscriber)
- [Anotherlife (@anotherlifemi) • Instagram photos and videos](https://www.instagram.com/anotherlifemi)

---
