# Deja Norm'al

---

## About

**Members:**

- Brian McIssac
- Christopher Morrow
- Brett Pudak
- Karl Woodward
- Jerrod Herrig
- Mike Mains

---

## Releases

---
### The Indifferent Beginnings Of The Modern Age

![[cover.jpg]]

**Tracklist**

1. A Leader Is Only As Good As His Country
2. Aromatic Armistice
3. Interlude To The Autumn Division
4. Three Leaves Falling
5. Tonight, The Sun Drowns Itself

---

### From Atop a Burning Building

![[DNFAABB cover.jpg]]

**Tracklist**

1. View of Coma
2. Cemetaries And Greyhound Buses
3. Goodbye Mr. Perfection
4. Valuntas Tua
5. Where Are The Angels Now?
6. Keep It Steady
7. From Atop A Burning Building
8. May
9. Our Perfect Ending
10. When Open Air Becomes A Battlefield
11. Life Is Just A Box
12. Wynona Ride-You

---

### This War Is Over

![[twio.jpg]]

**Tracklist**

1. View of Coma
2. Seven Days
3. Diet Coke and Mentos
4. A Letter To Write
5. The Great Escape
6. Goodbye Mr. Perfection

---

