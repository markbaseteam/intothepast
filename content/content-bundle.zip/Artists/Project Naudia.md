# Project Naudia

---

## About

**Members:** Dustin Smith

This is a project about Naudia Lightbringer: Hero, Time Traveler, Savior and the inspiration for an epic mix of rock and symphony.

---
## Hope Comes From The Future

![[Astro-HUD-1024x1024.png]]

**Tracklist**

1. To Infinity
2. And Beyond
3. Hello Houston
4. Astronaudia
5. Hope Comes From The Future
6. Caught In The Dream of Make Believe
7. I Can't Be Your Ghost Right Now
8. The Spacetime Symphony of Gravitational Waves

---

## Savior

![[28D705A4-0E8C-4675-9087-19E30D778DA5-2048x2046.jpg]]

**Tracklist**

1. Intro
2. Lightbringer
3. No Child Left Behind
4. Bright Eyes
5. Eleven
6. Death To Epstein Island
7. Save The Children
8. Safe and Sound
9. Bright Eyes (Amended)

---

## Classified

![[Championcover.jpg]]

**Tracklist**

1. Champion
2. Don't Leave Me Here
3. First Born
4. Portal

---