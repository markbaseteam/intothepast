# Hit The Reset

---

## About

**Members:** Dustin Smith

---

## After Dark

![[afterdark.jpg]]

**Tracklist**

1. After Dark
2. Elegy

---

## Anotherlife 

![[another life.jpg]]

**Tracklist**

1. Stuck in Your Ways
2. Karma
3. Straight Into Hell
4. I Just Need a Way Out
5. Stay Away
6. Another Life

---

## Links

- [Hit The Reset | Free Listening on SoundCloud](https://soundcloud.com/hitthereset)
- [Hit The Reset - YouTube](https://www.youtube.com/channel/UC14QcbpQ7L6_fBEFjW6khog)
- [Hit The Reset - Home](https://www.facebook.com/hittheresetmusic?ref=bookmarks)
- [Hit The Reset (@hittheresetmi) • Instagram photos and videos](https://www.instagram.com/hittheresetmi)
- [@hittheresetmi | Linktree](https://linktr.ee/hittheresetmi)
- [Hit The Reset - Home](https://www.facebook.com/hittheresetmusic)

---

