# The Casket Diaries

---

## About

Members: Dustin Smith

---

## Lyrics

- [[Lyrics]]

---

## Releases

- [[Endings]]
- [[Into The Unknown of The Cosmos]]
- [[Singles]]

---

## Links

**Artist:**

1. **The Casket Diaries** Apple Music
	ID: 1581811993  
	Link: [https://music.apple.com/artist/1581811993](https://music.apple.com/artist/1581811993)
1. **The Casket Diaries** Spotify

	Link: [The Casket Diaries | Spotify](https://open.spotify.com/artist/4DAr0QEahg3z5XJhx1KjU5)

- [The Casket Diaries](https://open.spotify.com/artist/4DAr0QEahg3z5XJhx1KjU5?si=wTO2dRD0R4GxfJv6ocAO3w)
- [The Casket Diaries on Apple Music](https://music.apple.com/us/artist/the-casket-diaries/1581811993)
- [The Casket Diaries](https://soundcloud.com/casket-diaries?utm_campaign=social_sharing&utm_source=mobi&utm_terms=pfy_plays_part_2.control&si=a766662503bb45cc924b30b75278a2ae)
- [The Casket Diaries](https://m.youtube.com/channel/UCUUC12JAiWWRX8fenlAMHrw)

---

