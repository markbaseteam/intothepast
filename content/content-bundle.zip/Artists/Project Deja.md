# Project Deja

---

## About

A reimagined project for the band Deja Norm'al.

**Members:**

- Brian McIssac
- Christopher Morrow
- Brett Pudak
- Karl Woodward
- Jerrod Herrig
- Mike Mains

**Reimagined By** Dustin Smith

---
## Reimagined

![[Reimagination.JPG]]

**Tracklist**

1. A Letter Unread
2. Cemtery Busses
3. Greyhound In The Cemetery
4. State of Coma
5. Letter 2 The Weeknd
6. Perfect Endings
7. The Great Escapist
8. The Battlefield For Air
9. Whats In The Box
10. When Open Air Becomes A Metalfield (Ada)
11. When Open Air Becomes A Metalfield
12. Open Air Is A Metalfield (Davinci)
13. When Open Air Becomes A Metalfield (Scratch Vox)
14. Intro
15. Acoustic Battlefield

---